# 線性混合效應模型平台｜GitHub Pages 網站

這是一個純 HTML、CSS、JavaScript 的靜態專題介紹網站，可免費部署於 GitHub Pages。

## 網站內容
- 專題摘要、研究背景與動機
- LMM 模型概念、固定效應與隨機效應
- 平台六項主要功能
- 平台操作流程
- 未來展望與改進方向
- 連結至既有 Shiny 分析平台：https://myappggg.shinyapps.io/LMM_shiny/

## 發佈到 GitHub Pages
1. 登入 GitHub，建立一個新的 **Public** repository，例如 `lmm-project`。
2. 將本資料夾內的 `index.html`、`style.css`、`script.js`、`README.md` 上傳至 repository 根目錄。
3. 進入 repository 的 **Settings → Pages**。
4. 在 **Build and deployment** 選擇 **Deploy from a branch**。
5. Branch 選 `main`，資料夾選 `/ (root)`，按 **Save**。
6. 等待部署完成，GitHub Pages 會提供網站網址，格式通常為 `https://你的帳號.github.io/lmm-project/`。

若 repository 名稱不是 `lmm-project`，網址最後一段會改成你的 repository 名稱。
